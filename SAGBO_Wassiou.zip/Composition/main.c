#include <stdio.h>
#include <stdlib.h>
#include "convertion.h"

int main()
{
    int nbre_ent;
    scanf("%d",&nbre_ent);
    convertion(nbre_ent);
    return 0;
}
