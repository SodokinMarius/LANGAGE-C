#ifndef CONVERTION_H_INCLUDED
#define CONVERTION_H_INCLUDED

void convertion (int n);

#endif // CONVERTION_H_INCLUDED
